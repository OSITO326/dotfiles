#!/bin/sh

# systray battery icon
cbatticon -u 5 &
# systray volume
volumeicon &
#feh wallpaper
feh --bg-scale /home/osito/Pictures/Wallpapers/Rick\ \&\ Morty\ 4.jpg
#set keymap
#setxkbmap -layout us -variant altgr-intl &
#set hdd mount automatically
#udiskie -t &
#set network-manager
#nm-applet &

